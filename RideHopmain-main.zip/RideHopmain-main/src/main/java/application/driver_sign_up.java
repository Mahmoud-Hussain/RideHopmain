package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Objects;

public class driver_sign_up {

    @FXML
    private TextField carnodriver;

    @FXML
    private TextField licensedriver;

    @FXML
    private TextField namedriver;

    @FXML
    private PasswordField passworddriver;

    @FXML
    private Button submit;
    @FXML
    private Button signupbutton2;

    @FXML
    void sign_up_submit_driver(ActionEvent event) throws IOException {
            Create_Account();
            SceneChangeTo1(event);
    }


    public  void Create_Account(){
        Database connecting = new Database();
        Connection connect_Database = connecting.getConnection();


        String Name =namedriver.getText();
        String Id = licensedriver.getText();
        String Password = passworddriver.getText();
        String carplate =  carnodriver.getText();




        String insert_Fields = "INSERT INTO driver (name,licenseno,Password,Carnumber) VALUES ('";
        String insertValues = Name +"','"+Id+"','"+Password+"','"+carplate+"')";

        String insertToRegister = insert_Fields + insertValues;


        String Check1 = "SELECT licenseno FROM driver WHERE licenseno = '"+Id+"'";

        try {
            Statement statement = connect_Database .createStatement();
            ResultSet rs1 = statement.executeQuery(Check1);

            if (rs1.next()){
                System.out.println("id exsist");
            }

            else {
                statement.executeUpdate(insertToRegister);
                System.out.println("done");
            }

        }
        catch (Exception e){
            e.printStackTrace();

        }


    }
    void SceneChangeTo1(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("loginController1.fxml")));
        Scene scene2 = new Scene(parent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene2);
        window.centerOnScreen();
        window.show();
    }

}
